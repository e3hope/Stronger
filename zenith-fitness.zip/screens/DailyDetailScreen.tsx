
import React from 'react';
import { WorkoutSession } from '../types';

interface DailyDetailScreenProps {
  workout: WorkoutSession | null;
  onBack: () => void;
}

const DailyDetailScreen: React.FC<DailyDetailScreenProps> = ({ workout, onBack }) => {
  if (!workout) return null;

  const dateStr = new Date(workout.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  return (
    <div className="flex flex-col min-h-full">
      <header className="flex-none bg-surface-dark border-b border-[#23483f] z-10 sticky top-0">
        <div className="flex items-center px-4 justify-between h-14">
          <button onClick={onBack} className="flex size-10 items-center justify-center rounded-full hover:bg-[#23483f] transition-colors shrink-0">
            <span className="material-symbols-outlined text-white" style={{ fontSize: '24px' }}>arrow_back_ios_new</span>
          </button>
          <div className="flex items-center justify-center gap-1 flex-1">
            <button className="flex size-8 items-center justify-center rounded-full hover:bg-[#23483f] transition-colors text-gray-400 active:scale-95">
              <span className="material-symbols-outlined" style={{ fontSize: '24px' }}>chevron_left</span>
            </button>
            <h2 className="text-lg font-bold leading-tight tracking-[-0.015em] text-center min-w-[120px]">{dateStr}, Today</h2>
            <button className="flex size-8 items-center justify-center rounded-full hover:bg-[#23483f] transition-colors text-gray-400 active:scale-95">
              <span className="material-symbols-outlined" style={{ fontSize: '24px' }}>chevron_right</span>
            </button>
          </div>
          <div className="flex items-center justify-end shrink-0">
            <button className="flex size-10 items-center justify-center rounded-full hover:bg-[#23483f] transition-colors text-primary">
              <span className="material-symbols-outlined" style={{ fontSize: '24px' }}>calendar_month</span>
            </button>
          </div>
        </div>
      </header>

      <div className="px-4 py-6 grid grid-cols-3 gap-4">
        <div className="bg-surface-dark p-3 rounded-xl border border-[#23483f] flex flex-col items-center shadow-sm">
          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">Volume</span>
          <span className="text-lg font-bold text-white">{workout.volume.toLocaleString()}<span className="text-xs font-normal ml-0.5 text-gray-500">kg</span></span>
        </div>
        <div className="bg-surface-dark p-3 rounded-xl border border-[#23483f] flex flex-col items-center shadow-sm">
          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">Sets</span>
          <span className="text-lg font-bold text-white">14</span>
        </div>
        <div className="bg-surface-dark p-3 rounded-xl border border-[#23483f] flex flex-col items-center shadow-sm">
          <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">Duration</span>
          <span className="text-lg font-bold text-white">{workout.duration}<span className="text-xs font-normal ml-0.5 text-gray-500">m</span></span>
        </div>
      </div>

      <div className="px-6 pb-2 flex items-center justify-between text-[10px] font-bold text-gray-500 uppercase tracking-widest">
        <span>Exercise</span>
        <div className="flex gap-2 pr-1">
          <span className="w-12 text-center">Sets</span>
          <span className="w-14 text-center">Weight</span>
          <span className="w-12 text-center">Reps</span>
        </div>
      </div>

      <div className="px-4 space-y-3 pb-32">
        {/* Mocking list items since WorkoutSession doesn't store full state yet */}
        {[
          { name: 'Barbell Squat', target: 'Legs', type: 'Compound', sets: 3, kg: 100, reps: 5 },
          { name: 'Bench Press', target: 'Chest', type: 'Compound', sets: 4, kg: 80, reps: 8 },
          { name: 'Deadlift', target: 'Back', type: 'Compound', sets: 3, kg: 120, reps: 3 },
          { name: 'Overhead Press', target: 'Shoulders', type: 'Compound', sets: 3, kg: 45, reps: 8 },
        ].map((item, i) => (
          <div key={i} className="relative flex items-center justify-between p-3 bg-surface-dark rounded-2xl border border-[#23483f] shadow-sm hover:border-primary/50 transition-colors group">
            <div className="flex items-center gap-3 flex-1 min-w-0 mr-2">
              <div className="size-10 rounded-full bg-primary/20 flex items-center justify-center text-primary shrink-0 group-hover:scale-110 transition-transform">
                <span className="material-symbols-outlined">fitness_center</span>
              </div>
              <div className="truncate">
                <h3 className="text-sm font-bold leading-tight truncate text-white">{item.name}</h3>
                <p className="text-[10px] text-gray-400 mt-0.5">{item.target} • {item.type}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <div className="flex flex-col items-center justify-center w-12 h-11 bg-[#152b26] rounded-lg relative">
                <label className="text-[9px] uppercase font-bold text-gray-500 absolute top-1">Set</label>
                <span className="text-white font-bold text-base pt-3">{item.sets}</span>
              </div>
              <div className="flex flex-col items-center justify-center w-14 h-11 bg-[#152b26] rounded-lg relative">
                <label className="text-[9px] uppercase font-bold text-gray-500 absolute top-1">Kg</label>
                <span className="text-white font-bold text-base pt-3">{item.kg}</span>
              </div>
              <div className="flex flex-col items-center justify-center w-12 h-11 bg-[#152b26] rounded-lg relative">
                <label className="text-[9px] uppercase font-bold text-gray-500 absolute top-1">Rep</label>
                <span className="text-white font-bold text-base pt-3">{item.reps}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DailyDetailScreen;
