
import React, { useState, useEffect } from 'react';
import { Routine, Exercise } from '../types';

interface RoutineDetailScreenProps {
  routine: Routine | null;
  onSave: (r: Routine) => void;
  onBack: () => void;
}

const RoutineDetailScreen: React.FC<RoutineDetailScreenProps> = ({ routine, onSave, onBack }) => {
  const [name, setName] = useState(routine?.name || '');
  const [exercises, setExercises] = useState<Exercise[]>(routine?.exercises || []);
  const [tags, setTags] = useState<string[]>(routine?.tags || []);

  const handleAddExercise = () => {
    const newEx: Exercise = {
      id: Math.random().toString(36).substr(2, 9),
      name: 'New Exercise',
      category: 'General',
      type: 'Compound',
      sets: [{ id: 's1', weight: 0, reps: 0 }]
    };
    setExercises([...exercises, newEx]);
  };

  const updateExercise = (id: string, updates: Partial<Exercise>) => {
    setExercises(exercises.map(ex => ex.id === id ? { ...ex, ...updates } : ex));
  };

  const addSet = (exId: string) => {
    setExercises(exercises.map(ex => {
      if (ex.id === exId) {
        return {
          ...ex,
          sets: [...ex.sets, { id: Math.random().toString(36).substr(2, 9), weight: 0, reps: 0 }]
        };
      }
      return ex;
    }));
  };

  const removeSet = (exId: string, setId: string) => {
    setExercises(exercises.map(ex => {
      if (ex.id === exId) {
        return {
          ...ex,
          sets: ex.sets.filter(s => s.id !== setId)
        };
      }
      return ex;
    }));
  };

  const updateSet = (exId: string, setId: string, updates: any) => {
    setExercises(exercises.map(ex => {
      if (ex.id === exId) {
        return {
          ...ex,
          sets: ex.sets.map(s => s.id === setId ? { ...s, ...updates } : s)
        };
      }
      return ex;
    }));
  };

  const handleSave = () => {
    onSave({
      id: routine?.id || Math.random().toString(36).substr(2, 9),
      name,
      exercises,
      tags,
      estimatedDuration: 45 // Fixed for simplicity
    });
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-dark">
      <header className="sticky top-0 z-50 bg-background-dark border-b border-white/5 px-4 h-14 flex items-center justify-between">
        <button onClick={onBack} className="flex items-center justify-center size-10 rounded-full hover:bg-white/10 transition-colors">
          <span className="material-symbols-outlined text-white">arrow_back</span>
        </button>
        <h1 className="text-lg font-bold tracking-tight">Routine Details</h1>
        <button 
          onClick={handleSave}
          className="px-3 py-1.5 rounded-full text-primary font-semibold hover:bg-primary/10 transition-colors text-sm"
        >
          Save
        </button>
      </header>

      <main className="flex-1 w-full max-w-md mx-auto flex flex-col pb-32">
        <section className="p-4 space-y-4">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-400">Routine Name</label>
            <input 
              className="w-full bg-input-dark border-none rounded-xl px-4 py-3 text-base text-white placeholder-gray-500 focus:ring-2 focus:ring-primary shadow-sm"
              placeholder="e.g. Leg Day Blast"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {tags.map(tag => (
              <div key={tag} className="flex items-center h-8 px-3 rounded-lg bg-primary/20 border border-primary/30 text-primary text-sm font-medium">
                {tag}
              </div>
            ))}
            <button className="flex items-center justify-center size-8 rounded-lg border border-dashed border-gray-500 text-gray-500 hover:text-primary hover:border-primary transition-colors">
              <span className="material-symbols-outlined text-[20px]">add</span>
            </button>
          </div>
        </section>

        <div className="h-px w-full bg-white/5 my-2"></div>

        <section className="p-4 space-y-4">
          <h2 className="text-sm font-medium text-gray-400 mb-2 px-1">Exercise List ({exercises.length})</h2>
          {exercises.map((ex, exIdx) => (
            <div key={ex.id} className="group bg-surface-dark rounded-xl overflow-hidden shadow-sm border border-transparent hover:border-primary/30 transition-all">
              <div className="flex items-center justify-between p-4 bg-black/20 border-b border-white/5">
                <div className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-gray-400">drag_indicator</span>
                  <div className="flex flex-col">
                    <input 
                      className="bg-transparent border-none p-0 focus:ring-0 font-bold text-white text-base"
                      value={ex.name}
                      onChange={(e) => updateExercise(ex.id, { name: e.target.value })}
                    />
                    <span className="text-xs text-gray-500">{ex.category} · {ex.type}</span>
                  </div>
                </div>
                <button className="size-8 flex items-center justify-center rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-colors">
                  <span className="material-symbols-outlined text-[20px]">more_vert</span>
                </button>
              </div>

              <div className="p-4 space-y-3">
                <div className="grid grid-cols-[32px_1fr_1fr_32px] gap-3 mb-2 px-1">
                  <div className="text-xs font-semibold text-center text-gray-500">SET</div>
                  <div className="text-xs font-semibold text-center text-gray-500">KG</div>
                  <div className="text-xs font-semibold text-center text-gray-500">REPS</div>
                  <div></div>
                </div>
                {ex.sets.map((set, setIdx) => (
                  <div key={set.id} className="grid grid-cols-[32px_1fr_1fr_32px] gap-3 items-center">
                    <div className="text-sm font-bold text-gray-400 text-center">{setIdx + 1}</div>
                    <input 
                      className="w-full bg-input-dark border-none rounded-lg text-center text-white font-medium focus:ring-1 focus:ring-primary p-2 h-10" 
                      type="number"
                      value={set.weight}
                      onChange={(e) => updateSet(ex.id, set.id, { weight: Number(e.target.value) })}
                    />
                    <input 
                      className="w-full bg-input-dark border-none rounded-lg text-center text-white font-medium focus:ring-1 focus:ring-primary p-2 h-10" 
                      type="number" 
                      value={set.reps}
                      onChange={(e) => updateSet(ex.id, set.id, { reps: Number(e.target.value) })}
                    />
                    <button 
                      onClick={() => removeSet(ex.id, set.id)}
                      className="flex items-center justify-center text-gray-500 hover:text-red-400 transition-colors"
                    >
                      <span className="material-symbols-outlined text-[20px]">close</span>
                    </button>
                  </div>
                ))}
              </div>

              <button 
                onClick={() => addSet(ex.id)}
                className="w-full py-3 text-sm font-semibold text-primary bg-primary/5 hover:bg-primary/10 transition-colors flex items-center justify-center gap-1 border-t border-white/5"
              >
                <span className="material-symbols-outlined text-[18px]">add</span>
                Add Set
              </button>
            </div>
          ))}

          {exercises.length === 0 && (
             <button 
              onClick={handleAddExercise}
              className="w-full p-8 border-2 border-dashed border-white/10 rounded-xl text-slate-500 hover:text-primary hover:border-primary transition-all flex flex-col items-center justify-center gap-2"
             >
                <span className="material-symbols-outlined text-4xl">fitness_center</span>
                <span>Add your first exercise</span>
             </button>
          )}
        </section>
      </main>

      <div className="fixed bottom-24 w-full max-w-md left-1/2 -translate-x-1/2 p-4 z-40">
        <button 
          onClick={handleAddExercise}
          className="flex items-center gap-2 bg-primary hover:bg-primary-dark text-background-dark font-bold text-lg py-4 px-8 rounded-full shadow-lg shadow-primary/20 transition-transform active:scale-95 w-full justify-center"
        >
          <span className="material-symbols-outlined">add</span>
          Add Exercise
        </button>
      </div>
    </div>
  );
};

export default RoutineDetailScreen;
