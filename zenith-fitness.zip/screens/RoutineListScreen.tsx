
import React from 'react';
import { Routine } from '../types';

interface RoutineListScreenProps {
  routines: Routine[];
  onEditRoutine: (r: Routine) => void;
  onAddRoutine: () => void;
}

const RoutineListScreen: React.FC<RoutineListScreenProps> = ({ routines, onEditRoutine, onAddRoutine }) => {
  return (
    <div className="flex flex-col min-h-full">
      <header className="flex flex-col gap-4 px-6 pt-12 pb-4 bg-background-dark sticky top-0 z-10">
        <div className="flex items-center justify-between h-10">
          <div />
          <button className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-white/10 transition-colors">
            <span className="material-symbols-outlined text-white" style={{ fontSize: '28px' }}>settings</span>
          </button>
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-white leading-tight">My Routines</h1>
      </header>

      <main className="flex-1 flex flex-col gap-4 px-4 pb-24 overflow-y-auto">
        {routines.map((routine) => (
          <div 
            key={routine.id}
            onClick={() => onEditRoutine(routine)}
            className="group relative flex items-center justify-between gap-4 p-4 rounded-2xl bg-surface-dark shadow-sm border border-white/5 active:scale-[0.98] transition-all cursor-pointer hover:shadow-md hover:bg-[#1c3a32]"
          >
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center shrink-0 w-14 h-14 rounded-xl bg-[#23483f]">
                <span className="material-symbols-outlined text-white" style={{ fontSize: '28px' }}>fitness_center</span>
              </div>
              <div className="flex flex-col justify-center">
                <h3 className="text-base font-semibold text-white leading-tight mb-1">{routine.name}</h3>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-[#91cabc] font-medium">{routine.exercises.length} Exercises</span>
                  <span className="w-1 h-1 rounded-full bg-[#91cabc]/40"></span>
                  <span className="text-sm text-[#91cabc]">~{routine.estimatedDuration || 0} mins</span>
                </div>
              </div>
            </div>
            <div className="shrink-0 text-gray-500 group-hover:text-primary transition-colors">
              <span className="material-symbols-outlined">chevron_right</span>
            </div>
          </div>
        ))}

        {routines.length === 0 && (
           <div className="text-center p-12 text-slate-500">
             No routines found. Create one to get started!
           </div>
        )}
        
        <div className="h-10"></div>
      </main>

      <div className="fixed bottom-24 left-0 right-0 px-6 flex justify-end pointer-events-none z-50">
        <button 
          onClick={onAddRoutine}
          className="pointer-events-auto shadow-lg shadow-primary/20 flex items-center gap-2 h-14 pl-5 pr-6 bg-primary text-background-dark rounded-xl font-bold text-base tracking-wide hover:brightness-110 hover:scale-105 transition-all active:scale-95"
        >
          <span className="material-symbols-outlined" style={{ fontSize: '24px' }}>add</span>
          <span>Create New Routine</span>
        </button>
      </div>
    </div>
  );
};

export default RoutineListScreen;
