
import React, { useState } from 'react';
import { WorkoutSession } from '../types';

interface CalendarScreenProps {
  workouts: WorkoutSession[];
  onViewWorkout: (w: WorkoutSession) => void;
}

const CalendarScreen: React.FC<CalendarScreenProps> = ({ workouts, onViewWorkout }) => {
  const [currentDate, setCurrentDate] = useState(new Date(2023, 9, 12)); // Oct 2023 as per screenshots

  const daysInMonth = (month: number, year: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (month: number, year: number) => new Date(year, month, 1).getDay();

  const monthName = currentDate.toLocaleString('default', { month: 'long' });
  const year = currentDate.getFullYear();
  
  const days = Array.from({ length: daysInMonth(currentDate.getMonth(), year) }, (_, i) => i + 1);
  const offset = Array.from({ length: firstDayOfMonth(currentDate.getMonth(), year) }, (_, i) => i);

  const getWorkoutForDay = (day: number) => {
    return workouts.find(w => {
      const d = new Date(w.date);
      return d.getDate() === day && d.getMonth() === currentDate.getMonth() && d.getFullYear() === year;
    });
  };

  const selectedDay = 12; // Just for UI demonstration matching screenshots
  const activeWorkout = getWorkoutForDay(selectedDay);

  return (
    <div className="flex flex-col">
      <div className="flex-none flex items-center p-4 pb-2 justify-between sticky top-0 bg-background-dark/95 backdrop-blur-sm z-30">
        <button className="text-white flex size-10 items-center justify-center rounded-full hover:bg-white/5 active:scale-95 transition-all">
          <span className="material-symbols-outlined text-[24px]">arrow_back</span>
        </button>
        <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center pr-10">Workout Log</h2>
        <div className="absolute right-4 flex items-center justify-end">
          <button className="text-primary text-xs font-bold uppercase tracking-wider shrink-0 bg-primary/10 px-3 py-1.5 rounded-full hover:bg-primary/20 transition-colors">Today</button>
        </div>
      </div>

      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <button 
          onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))}
          className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-white/5 text-slate-400 active:scale-95 transition-all"
        >
          <span className="material-symbols-outlined">chevron_left</span>
        </button>
        <p className="text-white text-xl font-bold leading-tight tracking-tight">{monthName} {year}</p>
        <button 
          onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))}
          className="flex items-center justify-center w-10 h-10 rounded-full hover:bg-white/5 text-slate-400 active:scale-95 transition-all"
        >
          <span className="material-symbols-outlined">chevron_right</span>
        </button>
      </div>

      <div className="flex flex-col gap-0.5 px-4 pb-6">
        <div className="grid grid-cols-7 mb-3 mt-2">
          {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => (
            <p key={d} className="text-slate-500 text-[12px] font-bold text-center uppercase tracking-widest">{d}</p>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-y-3 gap-x-1">
          {offset.map(i => <div key={`off-${i}`} className="h-10 w-full" />)}
          {days.map(day => {
            const hasWorkout = getWorkoutForDay(day);
            const isSelected = day === selectedDay;
            return (
              <button key={day} className="h-10 w-full flex items-center justify-center group relative">
                <div className={`
                  flex size-9 items-center justify-center rounded-lg font-medium text-sm transition-all
                  ${hasWorkout ? 'bg-primary text-background-dark font-bold shadow-[0_0_12px_rgba(25,240,186,0.4)]' : 'text-slate-300 group-hover:bg-white/5'}
                  ${isSelected ? 'border-2 border-primary bg-primary/10 text-primary shadow-[inset_0_0_8px_rgba(25,240,186,0.2)]' : ''}
                `}>
                  {day}
                  {isSelected && <div className="absolute -bottom-1 w-1 h-1 rounded-full bg-primary"></div>}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-4 pb-6">
        {activeWorkout ? (
          <div className="flex flex-col gap-4 rounded-xl border border-primary/20 bg-surface-dark p-5 shadow-lg relative overflow-hidden group">
            <div className="absolute -right-4 -top-4 size-24 bg-primary/10 rounded-full blur-2xl group-hover:bg-primary/20 transition-all"></div>
            <div className="flex items-center justify-between relative z-10">
              <div className="flex flex-col gap-1">
                <p className="text-white text-lg font-bold leading-tight">{monthName} {selectedDay}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="material-symbols-outlined text-primary text-[18px]">fitness_center</span>
                  <p className="text-slate-300 text-sm font-medium">{activeWorkout.routineName}</p>
                </div>
              </div>
              <button 
                onClick={() => onViewWorkout(activeWorkout)}
                className="flex items-center justify-center rounded-lg h-9 px-4 bg-primary text-background-dark text-sm font-bold shadow-lg shadow-primary/20 hover:bg-white hover:text-background-dark transition-all"
              >
                View
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3 pt-2 relative z-10">
              <div className="flex flex-col gap-1">
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Duration</span>
                <span className="text-white font-bold text-sm">{activeWorkout.duration}m</span>
              </div>
              <div className="flex flex-col gap-1 border-l border-white/10 pl-3">
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Volume</span>
                <span className="text-white font-bold text-sm">{activeWorkout.volume.toLocaleString()}kg</span>
              </div>
              <div className="flex flex-col gap-1 border-l border-white/10 pl-3">
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">PRs</span>
                <div className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-yellow-400 text-[14px] material-symbols-filled">emoji_events</span>
                  <span className="text-white font-bold text-sm">{activeWorkout.prs}</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-8 text-center text-slate-500 bg-surface-dark/50 rounded-xl border border-dashed border-white/10">
            No workout logged for this day
          </div>
        )}
      </div>

      <div className="px-4 pb-8">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-slate-400 text-xs font-bold uppercase tracking-widest">Monthly Stats</h3>
          <button className="text-primary text-xs hover:underline">View Report</button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col justify-between rounded-xl bg-surface-dark border border-white/5 p-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-3 opacity-10">
              <span className="material-symbols-outlined text-white text-[48px]">calendar_today</span>
            </div>
            <p className="text-slate-400 text-xs font-medium mb-2">Workouts</p>
            <div className="flex items-baseline gap-1">
              <p className="text-white text-3xl font-bold tracking-tight">15</p>
              <span className="text-primary text-xs font-bold">days</span>
            </div>
            <div className="w-full bg-background-dark h-1 rounded-full mt-3 overflow-hidden">
              <div className="bg-primary h-full w-[50%] rounded-full"></div>
            </div>
          </div>
          <div className="flex flex-col justify-between rounded-xl bg-surface-dark border border-white/5 p-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-3 opacity-10">
              <span className="material-symbols-outlined text-white text-[48px]">schedule</span>
            </div>
            <p className="text-slate-400 text-xs font-medium mb-2">Total Time</p>
            <div className="flex items-baseline gap-1">
              <p className="text-white text-3xl font-bold tracking-tight">12</p>
              <span className="text-slate-400 text-xs font-bold">hrs</span>
            </div>
            <p className="text-green-400 text-[10px] mt-3 font-medium flex items-center gap-0.5">
              <span className="material-symbols-outlined text-[12px]">trending_up</span>
              +2h vs Sept
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalendarScreen;
