
import React from 'react';
import { WorkoutSession } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface StatsScreenProps {
  workouts: WorkoutSession[];
}

const StatsScreen: React.FC<StatsScreenProps> = ({ workouts }) => {
  // Prep chart data
  const data = [
    { name: 'Mon', volume: 2400 },
    { name: 'Tue', volume: 1398 },
    { name: 'Wed', volume: 9800 },
    { name: 'Thu', volume: 3908 },
    { name: 'Fri', volume: 4800 },
    { name: 'Sat', volume: 3800 },
    { name: 'Sun', volume: 4300 },
  ];

  return (
    <div className="p-6 pb-32">
      <header className="mb-8">
        <h1 className="text-3xl font-bold mb-1">Performance</h1>
        <p className="text-slate-400">Weekly Progress Analysis</p>
      </header>

      <div className="space-y-6">
        <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold">Weekly Volume</h3>
            <span className="text-primary text-xs font-bold bg-primary/10 px-2 py-1 rounded-lg">+12% vs last week</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff10" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} dy={10} />
                <Tooltip 
                  cursor={{ fill: '#ffffff05' }}
                  contentStyle={{ backgroundColor: '#162e28', border: '1px solid rgba(25,240,186,0.2)', borderRadius: '12px', color: '#fff' }}
                />
                <Bar dataKey="volume" radius={[4, 4, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 2 ? '#19f0ba' : '#19f0ba30'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-surface-dark p-5 rounded-2xl border border-white/5 text-center">
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-2">Total Lifted</p>
            <p className="text-3xl font-bold">124.5<span className="text-sm text-slate-500 ml-1">t</span></p>
          </div>
          <div className="bg-surface-dark p-5 rounded-2xl border border-white/5 text-center">
            <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-2">PRs Set</p>
            <p className="text-3xl font-bold text-primary">28</p>
          </div>
        </div>

        <section className="bg-surface-dark p-5 rounded-2xl border border-white/5">
          <h3 className="font-bold mb-4">Muscle Focus</h3>
          <div className="space-y-4">
            {[
              { label: 'Chest', progress: 85 },
              { label: 'Back', progress: 65 },
              { label: 'Legs', progress: 45 },
              { label: 'Shoulders', progress: 75 },
            ].map(item => (
              <div key={item.label} className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">{item.label}</span>
                  <span className="text-primary font-bold">{item.progress}%</span>
                </div>
                <div className="h-2 w-full bg-background-dark rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full" style={{ width: `${item.progress}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default StatsScreen;
