
import React, { useState, useEffect } from 'react';
import { ScreenType, Routine, WorkoutSession } from './types';
import { INITIAL_ROUTINES, INITIAL_WORKOUTS } from './constants';
import Navbar from './components/Navbar';
import CalendarScreen from './screens/CalendarScreen';
import RoutineListScreen from './screens/RoutineListScreen';
import RoutineDetailScreen from './screens/RoutineDetailScreen';
import StatsScreen from './screens/StatsScreen';
import DailyDetailScreen from './screens/DailyDetailScreen';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('CALENDAR');
  const [routines, setRoutines] = useState<Routine[]>(INITIAL_ROUTINES);
  const [workouts, setWorkouts] = useState<WorkoutSession[]>(INITIAL_WORKOUTS);
  const [selectedRoutine, setSelectedRoutine] = useState<Routine | null>(null);
  const [selectedWorkout, setSelectedWorkout] = useState<WorkoutSession | null>(null);

  const navigateTo = (screen: ScreenType, data?: any) => {
    if (screen === 'ROUTINE_DETAIL') setSelectedRoutine(data || null);
    if (screen === 'DAILY_DETAIL') setSelectedWorkout(data || null);
    setCurrentScreen(screen);
  };

  const handleSaveRoutine = (updatedRoutine: Routine) => {
    setRoutines(prev => {
      const index = prev.findIndex(r => r.id === updatedRoutine.id);
      if (index > -1) {
        const next = [...prev];
        next[index] = updatedRoutine;
        return next;
      }
      return [...prev, updatedRoutine];
    });
    setCurrentScreen('ROUTINE_LIST');
  };

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-background-dark overflow-hidden relative shadow-2xl">
      <main className="flex-1 overflow-y-auto no-scrollbar pb-24">
        {currentScreen === 'CALENDAR' && (
          <CalendarScreen 
            workouts={workouts} 
            onViewWorkout={(w) => navigateTo('DAILY_DETAIL', w)} 
          />
        )}
        {currentScreen === 'ROUTINE_LIST' && (
          <RoutineListScreen 
            routines={routines} 
            onEditRoutine={(r) => navigateTo('ROUTINE_DETAIL', r)}
            onAddRoutine={() => navigateTo('ROUTINE_DETAIL')}
          />
        )}
        {currentScreen === 'ROUTINE_DETAIL' && (
          <RoutineDetailScreen 
            routine={selectedRoutine} 
            onSave={handleSaveRoutine}
            onBack={() => navigateTo('ROUTINE_LIST')} 
          />
        )}
        {currentScreen === 'DAILY_DETAIL' && (
          <DailyDetailScreen 
            workout={selectedWorkout} 
            onBack={() => navigateTo('CALENDAR')} 
          />
        )}
        {currentScreen === 'STATS' && <StatsScreen workouts={workouts} />}
        {currentScreen === 'PROFILE' && (
           <div className="p-8 text-center flex flex-col items-center justify-center h-full">
              <div className="w-24 h-24 rounded-full bg-surface-dark border-2 border-primary flex items-center justify-center mb-4">
                 <span className="material-symbols-outlined text-4xl text-primary">person</span>
              </div>
              <h2 className="text-2xl font-bold">Alex Johnson</h2>
              <p className="text-slate-400">Zenith Athlete</p>
           </div>
        )}
      </main>

      <Navbar currentScreen={currentScreen} onNavigate={navigateTo} />
    </div>
  );
};

export default App;
