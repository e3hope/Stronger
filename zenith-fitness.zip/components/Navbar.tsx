
import React from 'react';
import { ScreenType } from '../types';

interface NavbarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentScreen, onNavigate }) => {
  const isSelected = (screen: ScreenType) => currentScreen === screen;

  return (
    <div className="flex-none absolute bottom-0 w-full border-t border-white/5 bg-surface-dark/95 backdrop-blur-md px-4 pb-6 pt-3 z-40">
      <div className="flex gap-2 justify-between items-center px-2">
        <button 
          onClick={() => onNavigate('ROUTINE_LIST')}
          className={`flex flex-1 flex-col items-center justify-center gap-1 transition-colors group ${isSelected('ROUTINE_LIST') ? 'text-primary' : 'text-slate-400 hover:text-primary'}`}
        >
          <span className={`material-symbols-outlined text-[24px] ${isSelected('ROUTINE_LIST') ? 'material-symbols-filled' : ''}`}>home</span>
          <p className="text-[10px] font-medium tracking-wide">Routines</p>
        </button>

        <button 
          onClick={() => onNavigate('CALENDAR')}
          className={`flex flex-1 flex-col items-center justify-center gap-1 transition-colors relative ${isSelected('CALENDAR') || isSelected('DAILY_DETAIL') ? 'text-primary' : 'text-slate-400 hover:text-primary'}`}
        >
          {isSelected('CALENDAR') && <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-primary/20 rounded-full blur-md"></div>}
          <span className={`material-symbols-outlined text-[24px] relative z-10 ${isSelected('CALENDAR') ? 'material-symbols-filled' : ''}`}>calendar_month</span>
          <p className="text-[10px] font-bold tracking-wide relative z-10">Calendar</p>
        </button>

        <div className="relative -top-8 mx-2">
          <button 
            onClick={() => onNavigate('ROUTINE_DETAIL')}
            className="flex size-14 items-center justify-center rounded-full bg-primary text-background-dark shadow-[0_4px_20px_rgba(25,240,186,0.5)] hover:scale-110 active:scale-95 transition-all border-4 border-background-dark"
          >
            <span className="material-symbols-outlined text-[32px]">add</span>
          </button>
        </div>

        <button 
          onClick={() => onNavigate('STATS')}
          className={`flex flex-1 flex-col items-center justify-center gap-1 transition-colors group ${isSelected('STATS') ? 'text-primary' : 'text-slate-400 hover:text-primary'}`}
        >
          <span className={`material-symbols-outlined text-[24px] ${isSelected('STATS') ? 'material-symbols-filled' : ''}`}>bar_chart</span>
          <p className="text-[10px] font-medium tracking-wide">Stats</p>
        </button>

        <button 
          onClick={() => onNavigate('PROFILE')}
          className={`flex flex-1 flex-col items-center justify-center gap-1 transition-colors group ${isSelected('PROFILE') ? 'text-primary' : 'text-slate-400 hover:text-primary'}`}
        >
          <span className={`material-symbols-outlined text-[24px] ${isSelected('PROFILE') ? 'material-symbols-filled' : ''}`}>person</span>
          <p className="text-[10px] font-medium tracking-wide">Profile</p>
        </button>
      </div>
    </div>
  );
};

export default Navbar;
