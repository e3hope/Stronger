
export interface Set {
  id: string;
  weight: number;
  reps: number;
}

export interface Exercise {
  id: string;
  name: string;
  category: string;
  type: string; // 'Compound', 'Isolation', etc.
  sets: Set[];
}

export interface Routine {
  id: string;
  name: string;
  exercises: Exercise[];
  estimatedDuration?: number; // in minutes
  tags: string[];
}

export interface WorkoutSession {
  id: string;
  date: string; // ISO string
  routineName: string;
  duration: number; // minutes
  volume: number; // kg
  prs: number;
  exercises: Exercise[];
}

export type ScreenType = 'HOME' | 'CALENDAR' | 'STATS' | 'PROFILE' | 'ROUTINE_DETAIL' | 'DAILY_DETAIL' | 'ROUTINE_LIST';
